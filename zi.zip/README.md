# ziyou

№УСТАНОВКА ДЛЯ Linux
```sh
$ sudo apt update
$ sudo apt install -y python3-pip python3-venv tshark
$ git clone https://github.com/juustAn0rd1naryN1ck/ziyou
$ cd ziyou
$ python3 -m venv venv
$ source ./venv/bin/activate
$ sudo pip3 install -r requirements.txt
$ sudo python3 main.py
```
